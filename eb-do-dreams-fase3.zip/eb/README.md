# EB DO DREAMS — Fases 1 e 3

Next.js 14 (App Router) + TypeScript + Tailwind + PostgreSQL (`pg`).

## Rodar

```bash
npm install
cp .env.example .env        # preencha DATABASE_URL e ADMIN_ROBLOX_IDS
export $(grep -v '^#' .env | xargs)
npm run db:init             # cria as tabelas (db/schema.sql)
npm run dev
```

Em produção use HTTPS e `COOKIE_SECURE=true`.

## O que a Fase 1 entrega

- Tela de identificação, verificação Roblox pela bio em 3 etapas (feita no servidor, sem pedir senha)
- Sessões em cookie httpOnly, com hash do token no banco
- Painel: cabeçalho fixo, menu lateral (busca, atalhos, seções), barra inferior, Início (aviso, tutorial, guia),
  Perfil (e-mail editável), Patente, notificações (estado vazio), cookies, PWA (manifest, service worker, botão App)
- Esquema do banco completo para as fases seguintes (`db/schema.sql`)

## Fase 3 (carreira e quartel)

- **Hierarquia:** categorias e patentes vêm do banco. Só o Alto Comando cadastra/apaga (botão "Gerenciar hierarquia").
  Comece criando as categorias e patentes oficiais — nada vem pré-cadastrado.
- **Histórico de Patentes:** busca por nick (só militares que já se verificaram). O Alto Comando registra promoção,
  rebaixamento, reversão ou ingresso; isso atualiza a patente, a folha de alterações, o Registro de Ações e gera notificação no banco.
  Ninguém altera a própria patente.
- **Registro de Ações:** linha do tempo somente leitura, com busca, filtros e modo compacto.
- **Novidades:** publicam Oficial e Alto Comando; só o Alto Comando apaga.
- Níveis de acesso: membro < instrutor < oficial < alto_comando (`lib/perm.ts`). A checagem é sempre no servidor.

## Como a verificação funciona

1. `/api/auth/roblox/lookup` busca o nick na API pública do Roblox (limite de 12 buscas/min por IP).
2. `/api/auth/roblox/start` gera o código (`dreams-palavra-1234`), guarda **só o hash** e entrega um cookie
   privado de desafio. O código vale 30 minutos.
3. `/api/auth/roblox/verify` lê a bio pública no Roblox, compara o hash, invalida o código (uso único),
   cria/atualiza o usuário e abre a sessão. Máximo de 15 tentativas por código.

Limitação: o limitador de tentativas fica em memória (uma instância). Com várias instâncias, use Redis.
Os IDs em `ADMIN_ROBLOX_IDS` entram como Alto Comando na primeira verificação; todos os demais entram como Membro.

## Próximas fases

3: Hierarquia, Histórico de Patentes, Registro de Ações, Novidades · 4: Entregar Patente, Divisões, Agenda, notificações ·
5: Discord OAuth2, Documentos, CDP, Códigos, Bugs e Ideias, painel admin.
Páginas ainda não construídas abrem uma tela "Fase X" em `/em-breve/...`.
