import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#080C0A", pine: "#101A14", mil: "#123D26",
        neon: "#20F36B", glow: "#35FF83", card: "#19201C",
        snow: "#F2F5F2", mute: "#A6AEA9"
      },
      fontFamily: {
        display: ["var(--font-display)", "Oswald", "sans-serif"],
        body: ["var(--font-body)", "Inter", "system-ui", "sans-serif"]
      },
      boxShadow: {
        neon: "0 0 0 1px rgba(32,243,107,.55), 0 0 22px rgba(32,243,107,.22)",
        btn: "0 4px 0 #0c7a37, 0 10px 22px rgba(32,243,107,.28)"
      }
    }
  },
  plugins: []
};
export default config;
