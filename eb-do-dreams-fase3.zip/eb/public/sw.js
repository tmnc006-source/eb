// Service worker mínimo: habilita instalação (PWA) e exibição de notificações push (Fase 4).
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", () => {});
self.addEventListener("push", (event) => {
  const data = event.data ? event.data.json() : {};
  event.waitUntil(self.registration.showNotification(data.title || "EB DO DREAMS", {
    body: data.body || "", icon: "/icon-192.png", badge: "/icon-192.png", data: { url: data.url || "/inicio" }
  }));
});
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(self.clients.openWindow(event.notification.data.url));
});
