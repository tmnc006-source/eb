import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser } from "@/lib/session";
import Emblem from "@/components/Emblem";
import GridMesh from "@/components/GridMesh";
import Icon from "@/components/Icon";

export default async function Identify() {
  if (await getUser()) redirect("/inicio");
  return (
    <main className="relative flex min-h-dvh flex-col overflow-hidden">
      <header className="relative z-10 flex items-center gap-3 border-b border-white/5 bg-black/30 px-4 py-3 backdrop-blur">
        <Emblem size={38} />
        <div className="leading-tight">
          <div className="font-display text-xl font-bold tracking-wide">EB DO DREAMS</div>
          <div className="text-[11px] tracking-[.12em] text-mute">EXÉRCITO BRASILEIRO NO ROBLOX</div>
        </div>
      </header>

      <section className="anim-page relative z-10 mx-auto flex w-full max-w-xl flex-1 flex-col justify-center px-6 pb-40">
        <h1 className="font-display text-6xl font-bold leading-none sm:text-7xl">IDENTIFIQUE-SE.</h1>
        <div className="mt-4 flex gap-2" aria-hidden="true">
          <span className="h-1 w-16 rounded bg-neon shadow-[0_0_10px_#20F36B]" /><span className="h-1 w-16 rounded bg-white/70" /><span className="h-1 w-16 rounded bg-white/20" />
        </div>
        <p className="mt-5 max-w-sm text-lg text-mute">Verifique sua conta do Roblox pela bio para entrar.</p>
        <Link href="/entrar" className="btn mt-7 w-fit text-lg"><Icon name="id" /> Entrar pela bio</Link>
      </section>

      <GridMesh />
    </main>
  );
}
