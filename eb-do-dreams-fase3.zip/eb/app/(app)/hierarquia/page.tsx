import { query } from "@/lib/db";
import { getUser } from "@/lib/session";
import { has } from "@/lib/perm";
import Icon from "@/components/Icon";
import { DeleteBtn, HierarchyAdmin } from "@/components/AdminForms";

type Cat = { id: number; name: string; color: string };
type Rank = { id: number; category_id: number; name: string; abbreviation: string; position: number };

export default async function Hierarquia() {
  const u = (await getUser())!;
  const admin = has(u.role, "alto_comando");
  const cats = await query<Cat>("SELECT id,name,color FROM rank_categories ORDER BY position DESC, id");
  const ranks = await query<Rank>("SELECT id,category_id,name,abbreviation,position FROM ranks ORDER BY position DESC, id");
  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-display text-3xl font-bold">Hierarquia</h2><div className="scan-line mt-2 w-14" />
        <p className="mt-2 text-mute">Toda a estrutura de patentes do EB DO DREAMS, como o Alto Comando cadastrou.</p>
      </div>
      {admin && <HierarchyAdmin cats={cats.map((c) => ({ id: c.id, name: c.name }))} />}
      {cats.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/20 p-8 text-center text-mute"><Icon name="layers" size={30} className="mx-auto mb-2 text-glow" />
          {admin ? "Nenhuma categoria ainda. Use “Gerenciar hierarquia” para cadastrar a primeira." : "A hierarquia ainda não foi cadastrada pelo Alto Comando."}</div>
      ) : cats.map((c) => (
        <section key={c.id}>
          <h3 className="mb-2 flex items-center gap-2 font-display text-xl font-bold"><span className="h-3 w-3 rounded-full" style={{ background: c.color, boxShadow: `0 0 10px ${c.color}` }} />{c.name}
            {admin && <DeleteBtn kind="Category" id={c.id} />}</h3>
          <div className="space-y-2 border-l-2 pl-3" style={{ borderColor: c.color }}>
            {ranks.filter((r) => r.category_id === c.id).map((r) => (
              <div key={r.id} className="flex items-center gap-3 rounded-xl border border-white/5 bg-card p-3">
                <span className="grid h-9 min-w-9 place-items-center rounded-lg border px-1 font-display font-bold" style={{ borderColor: c.color, color: c.color }}>{r.position}</span>
                <span className="font-semibold"><span className="text-mute">[{r.abbreviation}]</span> {r.name}</span>
                {admin && <span className="ml-auto"><DeleteBtn kind="Rank" id={r.id} /></span>}
              </div>))}
            {!ranks.some((r) => r.category_id === c.id) && <p className="text-sm text-mute">Sem patentes nesta categoria.</p>}
          </div>
        </section>))}
    </div>
  );
}
