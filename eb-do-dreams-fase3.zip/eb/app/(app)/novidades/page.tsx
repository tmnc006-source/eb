import { query } from "@/lib/db";
import { getUser } from "@/lib/session";
import { has } from "@/lib/perm";
import Icon from "@/components/Icon";
import { DeleteNews, NewsForm } from "@/components/AdminForms";

type N = { id: string; title: string; body: string; category: string | null; image_url: string | null; created_at: string; author: string | null };

export default async function Novidades() {
  const u = (await getUser())!;
  const items = await query<N>(`SELECT n.id::text, n.title, n.body, n.category, n.image_url, n.created_at, a.roblox_username AS author
    FROM news n LEFT JOIN users a ON a.id=n.author_id ORDER BY n.created_at DESC LIMIT 50`);
  return (
    <div className="space-y-4">
      <div><h2 className="font-display text-3xl font-bold">Novidades</h2><div className="scan-line mt-2 w-14" />
        <p className="mt-2 text-mute">Comunicados e atualizações oficiais do EB DO DREAMS.</p></div>
      {has(u.role, "oficial") && <NewsForm />}
      {items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/20 p-8 text-center text-mute"><Icon name="sparkles" size={30} className="mx-auto mb-2 text-glow" />Nenhum comunicado publicado ainda.</div>
      ) : items.map((n, i) => {
        const fresh = Date.now() - new Date(n.created_at).getTime() < 7 * 864e5;
        return (
          <article key={n.id} className="panel-neon overflow-hidden">
            {n.image_url && /* eslint-disable-next-line @next/next/no-img-element */ <img src={n.image_url} alt="" className="h-40 w-full object-cover" loading="lazy" referrerPolicy="no-referrer" />}
            <div className="p-4">
              <div className="mb-2 flex flex-wrap items-center gap-2 text-xs">
                {fresh && i === 0 && <span className="rounded-md bg-neon px-2 py-0.5 font-bold text-ink">Mais recente</span>}
                {n.category && <span className="rounded-md bg-white/10 px-2 py-0.5">{n.category}</span>}
                <time className="text-mute">{new Date(n.created_at).toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" })}</time>
                {has(u.role, "alto_comando") && <span className="ml-auto"><DeleteNews id={Number(n.id)} /></span>}</div>
              <h3 className="font-display text-2xl font-bold text-glow">{n.title}</h3>
              <p className="mt-1 whitespace-pre-line text-[15px] leading-relaxed text-mute">{n.body}</p>
              {n.author && <p className="mt-2 text-xs text-mute">Publicado por @{n.author}</p>}
            </div>
          </article>);
      })}
    </div>
  );
}
