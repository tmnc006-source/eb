import Link from "next/link";
import { notFound } from "next/navigation";
import { ALL_ITEMS } from "@/lib/nav";
import Icon from "@/components/Icon";

export default function EmBreve({ params }: { params: { slug: string } }) {
  const item = ALL_ITEMS.find((i) => i.href === `/em-breve/${params.slug}`);
  if (!item) notFound();
  return (
    <section className="panel-neon mt-6 p-6 text-center">
      <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-mil text-glow"><Icon name={item.icon} size={28} /></span>
      <h2 className="mt-3 font-display text-3xl font-bold">{item.label}</h2>
      <p className="mt-2 text-mute">{item.blurb}</p>
      <p className="mt-4 rounded-xl bg-black/30 p-3 text-sm">Esta ferramenta entra na <b className="text-glow">Fase {item.phase}</b> do desenvolvimento e ainda não está disponível.</p>
      <Link href="/inicio" className="btn mt-5">Voltar ao início</Link>
    </section>
  );
}
