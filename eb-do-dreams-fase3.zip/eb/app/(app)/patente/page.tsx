import { getUser } from "@/lib/session";
import { query } from "@/lib/db";
import Icon from "@/components/Icon";

type H = { kind: string; reason: string | null; created_at: string; from_name: string | null; to_name: string | null; actor: string | null };
const KIND: Record<string, string> = { promocao: "Promoção", rebaixamento: "Rebaixamento", reversao: "Reversão", ingresso: "Ingresso", banimento: "Banimento" };

export default async function Patente() {
  const u = (await getUser())!;
  const hist = await query<H>(
    `SELECT h.kind, h.reason, h.created_at, f.name AS from_name, t.name AS to_name, a.roblox_username AS actor
       FROM rank_history h LEFT JOIN ranks f ON f.id = h.from_rank_id LEFT JOIN ranks t ON t.id = h.to_rank_id
       LEFT JOIN users a ON a.id = h.actor_id WHERE h.user_id = $1 ORDER BY h.created_at DESC LIMIT 50`, [u.id]);
  return (
    <div className="space-y-4">
      <section className="panel-neon p-5">
        <div className="flex items-center gap-3 text-mute"><Icon name="medal" /> Patente atual</div>
        <h2 className="mt-1 font-display text-4xl font-bold">{u.rank_name ?? "Sem patente registrada"}</h2>
        {u.rank_abbr && <span className="chip mt-2 inline-block">{u.rank_abbr}</span>}
        <p className="mt-3 text-sm text-mute">Unidade: <b className="text-snow">{u.division_name ?? "Sem divisão"}</b></p>
        {!u.rank_name && <p className="mt-3 text-sm text-mute">Sua patente aparece aqui assim que o Alto Comando ou um instrutor autorizado registrar a primeira movimentação.</p>}
      </section>
      <section className="panel p-4">
        <h3 className="mb-3 font-display text-2xl font-bold">Histórico de promoções</h3>
        {hist.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-white/20 p-6 text-center text-mute"><Icon name="scroll" size={28} className="mx-auto mb-2 text-glow" />Nenhuma movimentação registrada ainda.</div>
        ) : (
          <ol className="space-y-3 border-l border-neon/40 pl-4">
            {hist.map((h, i) => (
              <li key={i} className="relative"><span className="absolute -left-[22px] top-1.5 h-3 w-3 rounded-full bg-neon" />
                <div className="font-semibold">{KIND[h.kind] ?? h.kind}: {h.from_name ?? "—"} para {h.to_name ?? "—"}</div>
                <div className="text-xs text-mute">{new Date(h.created_at).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}{h.actor ? ` · por @${h.actor}` : ""}</div>
                {h.reason && <p className="text-sm text-mute">{h.reason}</p>}</li>))}
          </ol>)}
      </section>
    </div>
  );
}
