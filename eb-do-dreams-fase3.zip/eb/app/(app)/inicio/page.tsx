import Link from "next/link";
import Icon from "@/components/Icon";
import { FirstAccessNotice, Hero } from "@/components/HomeClient";

const GUIDE = [
  { icon: "check", title: "Entregar Patente", href: "/em-breve/entregar", text: "Adicione os nicks dos aprovados, informe o tipo de treino, anexe a prova e envie. Cada promoção é registrada na hora." },
  { icon: "shield", title: "Patentes nas Divisões", href: "/em-breve/divisoes", text: "Escolha a divisão, busque o membro e promova ou aceite o ingresso, respeitando a patente mínima de cada divisão." },
  { icon: "layers", title: "Hierarquia", href: "/hierarquia", text: "Todas as categorias e patentes do Exército, como o Alto Comando cadastrou." },
  { icon: "clipboard", title: "Registro de Ações", href: "/registro", text: "A linha do tempo de tudo o que foi feito na plataforma, com o responsável por cada ação." }
];

export default function Inicio() {
  return (
    <div className="space-y-5">
      <FirstAccessNotice />
      <div>
        <h2 className="flex items-center gap-3 font-display text-3xl font-bold"><span className="grid h-11 w-11 place-items-center rounded-full bg-neon text-ink"><Icon name="home" /></span>Início</h2>
        <div className="scan-line mt-2 w-14" />
        <p className="mt-2 text-mute">Documentação, diretrizes e créditos do EB DO DREAMS.</p>
      </div>
      <Hero />
      <section className="panel p-4">
        <div className="mb-3 flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-full bg-neon text-ink"><Icon name="book" /></span>
          <div className="leading-tight"><h2 className="font-display text-2xl font-bold">Como usar</h2><p className="text-sm text-mute">O essencial de cada ferramenta, em poucas linhas.</p></div></div>
        <div className="space-y-2.5">
          {GUIDE.map((g) => (
            <Link key={g.title} href={g.href} className="flex gap-3 rounded-2xl border border-white/5 bg-black/25 p-3 hover:border-neon/50">
              <Icon name={g.icon} className="mt-1 shrink-0 text-glow" />
              <div><div className="font-display text-lg font-bold">{g.title}</div><p className="text-sm leading-snug text-mute">{g.text}</p></div>
            </Link>))}
        </div>
      </section>
    </div>
  );
}
