import { getUser } from "@/lib/session";
import { getAvatar } from "@/lib/roblox";
import EmailForm from "@/components/EmailForm";

const fmt = (d: string) => new Date(d).toLocaleString("pt-BR", { dateStyle: "long", timeStyle: "short", timeZone: "America/Sao_Paulo" });
const ROLES: Record<string, string> = { membro: "Membro", instrutor: "Instrutor", oficial: "Oficial", alto_comando: "Alto Comando" };

export default async function Perfil() {
  const u = (await getUser())!;
  const avatar = await getAvatar(Number(u.roblox_id));
  const rows: [string, string][] = [
    ["Identificador Roblox", u.roblox_id], ["Patente", u.rank_name ? `${u.rank_abbr ? `[${u.rank_abbr}] ` : ""}${u.rank_name}` : "Sem patente registrada"],
    ["Divisão", u.division_name ?? "Sem divisão"], ["Nível de acesso", ROLES[u.role] ?? u.role],
    ["Situação da conta", u.status === "ativo" ? "Ativa" : u.status], ["Verificada em", fmt(u.verified_at)]
  ];
  return (
    <div className="space-y-4">
      <section className="panel-neon flex items-center gap-4 p-4">
        <div className="h-24 w-24 shrink-0 overflow-hidden rounded-2xl border-2 border-neon bg-black">{avatar && /* eslint-disable-next-line @next/next/no-img-element */ <img src={avatar} alt={`Avatar de ${u.roblox_username}`} className="h-full w-full object-cover" />}</div>
        <div className="min-w-0"><h2 className="truncate font-display text-3xl font-bold">@{u.roblox_username}</h2>
          {u.display_name && u.display_name !== u.roblox_username && <p className="truncate text-mute">{u.display_name}</p>}
          <span className="mt-1 inline-block rounded-full bg-mil px-3 py-0.5 text-xs font-semibold text-glow">Conta verificada</span></div>
      </section>
      <section className="panel divide-y divide-white/5">
        <h3 className="px-4 pt-4 font-display text-xl font-bold">Dados militares</h3>
        {rows.map(([k, v]) => <div key={k} className="flex justify-between gap-4 px-4 py-3 text-sm"><span className="text-mute">{k}</span><span className="text-right font-semibold">{v}</span></div>)}
      </section>
      <section className="panel p-4"><h3 className="mb-3 font-display text-xl font-bold">Dados pessoais</h3><EmailForm initial={u.email ?? ""} />
        <p className="mt-3 text-xs text-mute">O nick e o avatar vêm do Roblox e não podem ser editados aqui.</p></section>
    </div>
  );
}
