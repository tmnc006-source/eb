import { query } from "@/lib/db";
import { getUser } from "@/lib/session";
import { has } from "@/lib/perm";
import { getAvatar } from "@/lib/roblox";
import Icon from "@/components/Icon";
import { RankChangeForm } from "@/components/AdminForms";

type U = { id: string; roblox_id: string; roblox_username: string; rank_name: string | null; rank_abbr: string | null };
type H = { kind: string; reason: string | null; created_at: string; from_name: string | null; to_name: string | null; actor: string | null };
const KIND: Record<string, string> = { promocao: "Promoção", rebaixamento: "Rebaixamento", reversao: "Reversão", ingresso: "Ingresso", banimento: "Banimento" };

export default async function Historico({ searchParams }: { searchParams: { nick?: string } }) {
  const me = (await getUser())!;
  const nick = (searchParams.nick ?? "").trim().replace(/^@/, "").slice(0, 20);
  const valid = /^[A-Za-z0-9_]{3,20}$/.test(nick);
  let target: U | null = null, hist: H[] = [], avatar: string | null = null;
  if (valid) {
    target = (await query<U>(`SELECT u.id, u.roblox_id::text, u.roblox_username, r.name AS rank_name, r.abbreviation AS rank_abbr
      FROM users u LEFT JOIN ranks r ON r.id=u.rank_id WHERE lower(u.roblox_username)=lower($1)`, [nick]))[0] ?? null;
    if (target) {
      hist = await query<H>(`SELECT h.kind,h.reason,h.created_at,f.name AS from_name,t.name AS to_name,a.roblox_username AS actor
        FROM rank_history h LEFT JOIN ranks f ON f.id=h.from_rank_id LEFT JOIN ranks t ON t.id=h.to_rank_id LEFT JOIN users a ON a.id=h.actor_id
        WHERE h.user_id=$1 ORDER BY h.created_at DESC LIMIT 100`, [target.id]);
      avatar = await getAvatar(Number(target.roblox_id));
    }
  }
  const admin = has(me.role, "alto_comando");
  const ranks = admin ? (await query<{ id: number; name: string; abbreviation: string }>("SELECT id,name,abbreviation FROM ranks ORDER BY position DESC")).map((r) => ({ id: r.id, label: `[${r.abbreviation}] ${r.name}` })) : [];
  return (
    <div className="space-y-4">
      <div><h2 className="font-display text-3xl font-bold">HISTÓRICO DE PATENTES</h2><div className="scan-line mt-2 w-14" />
        <p className="mt-2 text-mute">Consulte o registro rigoroso de todas as promoções e rebaixamentos de um militar.</p></div>

      <form method="get" className="panel-neon p-4">
        <div className="mb-3 flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-full bg-neon text-ink"><Icon name="user" /></span>
          <div className="leading-tight"><h3 className="font-display text-2xl font-bold">Auditar militar</h3><p className="text-sm text-mute">Digite o nick do Roblox e veja cada promoção e rebaixamento registrado.</p></div></div>
        <div className="flex gap-2"><div className="relative flex-1"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-mute">@</span>
          <input name="nick" defaultValue={nick} className="input !pl-8" placeholder="nick" autoCapitalize="none" aria-label="Nick do Roblox" /></div>
          <button className="btn" aria-label="Pesquisar"><Icon name="search" /></button></div>
        {nick && !valid && <p className="mt-2 text-sm text-red-300">Use o nome de usuário: de 3 a 20 letras, números ou _.</p>}
      </form>

      {target && (
        <div className="panel flex items-center gap-3 p-3">
          <div className="h-14 w-14 overflow-hidden rounded-xl border border-neon/60 bg-black">{avatar && /* eslint-disable-next-line @next/next/no-img-element */ <img src={avatar} alt="" className="h-full w-full object-cover" />}</div>
          <div><div className="font-display text-xl font-bold">@{target.roblox_username}</div><div className="text-sm text-mute">{target.rank_name ? `[${target.rank_abbr}] ${target.rank_name}` : "Sem patente registrada"}</div></div>
        </div>)}

      {admin && target && <RankChangeForm ranks={ranks} nick={target.roblox_username} />}

      {valid && (
        <section className="overflow-hidden rounded-2xl bg-[#3fe381]/95 text-ink">
          <div className="inline-block rounded-br-xl bg-ink px-3 py-1 font-display text-sm font-bold tracking-wider text-glow">FOLHA DE ALTERAÇÕES</div>
          <div className="p-3">
            {hist.length === 0 ? (
              <div className="rounded-xl border-2 border-dashed border-ink/40 bg-white p-6 text-center"><Icon name="search" size={26} className="mx-auto mb-1 text-[#14803f]" />
                <p>Nenhum registro encontrado para este militar.</p>{!target && <p className="mt-1 text-xs text-[#4b5a50]">Esse nick ainda não entrou na plataforma.</p>}</div>
            ) : (
              <ol className="space-y-2">{hist.map((h, i) => (
                <li key={i} className="rounded-xl bg-white p-3 text-sm">
                  <div className="flex justify-between gap-2"><b>{KIND[h.kind] ?? h.kind}</b><span className="text-[#4b5a50]">{new Date(h.created_at).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo", dateStyle: "short", timeStyle: "short" })}</span></div>
                  <div>{h.from_name ?? "—"} → <b>{h.to_name ?? "—"}</b></div>
                  <div className="text-xs text-[#4b5a50]">Responsável: {h.actor ? `@${h.actor}` : "sistema"}{h.reason ? ` · ${h.reason}` : ""}</div></li>))}</ol>)}
          </div>
        </section>)}
    </div>
  );
}
