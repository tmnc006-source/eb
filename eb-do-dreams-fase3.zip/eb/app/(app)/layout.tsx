import { redirect } from "next/navigation";
import { getUser } from "@/lib/session";
import { getAvatar } from "@/lib/roblox";
import Shell from "@/components/Shell";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const u = await getUser();
  if (!u) redirect("/");
  const avatar = await getAvatar(Number(u.roblox_id));
  return (
    <Shell user={{ name: u.roblox_username, avatar, rank: u.rank_name, division: u.division_name }}>{children}</Shell>
  );
}
