import Link from "next/link";
import { query } from "@/lib/db";
import { getAvatars } from "@/lib/roblox";
import Icon from "@/components/Icon";

type Row = { id: string; kind: string; result: string; description: string; created_at: string; actor_name: string | null; actor_rid: string | null; actor_abbr: string | null; target_name: string | null };
const FILTERS: [string, string][] = [["", "Tudo"], ["bloqueio", "Bloqueios"], ["promocao", "Promoções"], ["rebaixamento", "Rebaixamentos"], ["reversao", "Reversões"], ["banimento", "Banimentos"], ["sistema", "Sistema Automático"]];
const LABEL: Record<string, string> = { bloqueio: "Bloqueio", promocao: "Promoção", rebaixamento: "Rebaixamento", reversao: "Reversão", banimento: "Banimento", sistema: "Sistema", ingresso: "Ingresso", config: "Configuração" };
const COLOR: Record<string, string> = { promocao: "#20F36B", rebaixamento: "#f5a524", reversao: "#38bdf8", banimento: "#ef4444", bloqueio: "#ef4444", sistema: "#A6AEA9", ingresso: "#20F36B", config: "#a78bfa" };

export default async function Registro({ searchParams }: { searchParams: { f?: string; q?: string; c?: string } }) {
  const f = FILTERS.some(([k]) => k === searchParams.f) ? searchParams.f! : "";
  const q = (searchParams.q ?? "").trim().slice(0, 40);
  const compact = searchParams.c === "1";
  const like = `%${q.replace(/[%_\\]/g, "\\$&")}%`;
  const rows = await query<Row>(
    `SELECT a.id::text, a.kind, a.result, a.description, a.created_at, au.roblox_username AS actor_name, au.roblox_id::text AS actor_rid,
            ar.abbreviation AS actor_abbr, tu.roblox_username AS target_name
       FROM audit_log a LEFT JOIN users au ON au.id=a.actor_id LEFT JOIN ranks ar ON ar.id=au.rank_id LEFT JOIN users tu ON tu.id=a.target_user_id
      WHERE ($1='' OR a.kind=$1) AND ($2='' OR au.roblox_username ILIKE $3 OR tu.roblox_username ILIKE $3 OR a.description ILIKE $3 OR a.kind ILIKE $3)
      ORDER BY a.created_at DESC LIMIT 60`, [f, q, like]);
  const avatars = await getAvatars(rows.map((r) => r.actor_rid).filter(Boolean) as string[]);
  const href = (over: Record<string, string>) => {
    const p = new URLSearchParams({ ...(f ? { f } : {}), ...(q ? { q } : {}), ...(compact ? { c: "1" } : {}), ...over });
    for (const [k, v] of [...p]) if (!v) p.delete(k);
    return `/registro${p.size ? `?${p}` : ""}`;
  };
  return (
    <div className="space-y-4">
      <div><h2 className="font-display text-3xl font-bold">Registro de Ações</h2><div className="scan-line mt-2 w-14" />
        <p className="mt-2 text-mute">Auditoria da plataforma. Cada registro mostra quem fez, o quê e quando, e não pode ser editado.</p></div>
      <form className="flex gap-2" method="get">
        {f && <input type="hidden" name="f" value={f} />}{compact && <input type="hidden" name="c" value="1" />}
        <div className="relative flex-1"><Icon name="search" size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-mute" />
          <input name="q" defaultValue={q} className="input !pl-10" placeholder="Filtrar por militar ou ação" aria-label="Filtrar por militar ou ação" /></div>
        <button className="btn" aria-label="Filtrar"><Icon name="search" /></button>
      </form>
      <div className="flex flex-wrap items-center gap-2">
        {FILTERS.map(([k, l]) => <Link key={k} href={href({ f: k })} className={`rounded-xl border px-3 py-1.5 text-sm ${f === k ? "border-dashed border-neon text-glow" : "border-white/10 bg-card"}`}>{l}</Link>)}
        <Link href={href({ c: compact ? "" : "1" })} className="ml-auto rounded-xl border border-white/10 bg-card px-3 py-1.5 text-sm">{compact ? "Detalhado" : "Compacto"}</Link>
      </div>
      {rows.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-white/20 p-8 text-center text-mute"><Icon name="clipboard" size={30} className="mx-auto mb-2 text-glow" />Nenhum registro encontrado para esse filtro.</div>
      ) : (
        <ol className="relative space-y-3 border-l border-white/10 pl-5">
          {rows.map((r) => (
            <li key={r.id} className="relative">
              <span className="absolute -left-[26px] top-3 h-3 w-3 rounded-full" style={{ background: COLOR[r.kind] ?? "#A6AEA9" }} />
              <div className="panel flex items-start gap-3 p-3">
                {!compact && <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full bg-black">{r.actor_rid && avatars[r.actor_rid] && /* eslint-disable-next-line @next/next/no-img-element */ <img src={avatars[r.actor_rid]} alt="" className="h-full w-full object-cover" />}</div>}
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2"><b className="truncate">{r.actor_name ? `@${r.actor_name}` : "Sistema automático"}</b>
                    <time className="shrink-0 text-xs text-mute">{new Date(r.created_at).toLocaleTimeString("pt-BR", { timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit" })}</time></div>
                  {!compact && r.actor_abbr && <div className="text-xs text-mute">[{r.actor_abbr}]</div>}
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-sm">
                    <span className="rounded-md px-1.5 py-0.5 text-xs font-bold text-ink" style={{ background: COLOR[r.kind] ?? "#A6AEA9" }}>{LABEL[r.kind] ?? r.kind}</span>
                    <span className="rounded-md bg-white/10 px-1.5 py-0.5 text-xs">{r.result === "ok" ? "OK" : r.result}</span>
                    {r.target_name && r.target_name !== r.actor_name && <span className="text-mute">alvo: @{r.target_name}</span>}</div>
                  {!compact && <p className="mt-1 text-sm text-mute">{r.description}</p>}
                  {!compact && <p className="mt-1 text-[11px] text-mute">{new Date(r.created_at).toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" })}</p>}
                </div>
              </div>
            </li>))}
        </ol>)}
    </div>
  );
}
