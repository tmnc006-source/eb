import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "EB DO DREAMS", short_name: "EB DREAMS", description: "Exército Brasileiro no Roblox",
    start_url: "/inicio", display: "standalone", background_color: "#080C0A", theme_color: "#080C0A",
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" }
    ]
  };
}
