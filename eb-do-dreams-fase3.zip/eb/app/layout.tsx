import type { Metadata, Viewport } from "next";
import { Barlow_Condensed, Inter } from "next/font/google";
import "./globals.css";
import PwaRegister from "@/components/PwaRegister";
import CookieBanner from "@/components/CookieBanner";

const display = Barlow_Condensed({ subsets: ["latin"], weight: ["500", "600", "700"], variable: "--font-display" });
const body = Inter({ subsets: ["latin"], variable: "--font-body" });

export const metadata: Metadata = {
  title: "EB DO DREAMS", description: "Exército Brasileiro no Roblox",
  icons: { icon: "/icon-192.png", apple: "/apple-icon.png" }
};
export const viewport: Viewport = { themeColor: "#080C0A", width: "device-width", initialScale: 1, viewportFit: "cover" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${display.variable} ${body.variable}`}>
      <body className="min-h-dvh font-body antialiased">
        {children}
        <CookieBanner />
        <PwaRegister />
      </body>
    </html>
  );
}
