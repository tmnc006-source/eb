import { NextResponse } from "next/server";
import { query } from "@/lib/db";
import { getUser } from "@/lib/session";
import { has } from "@/lib/perm";

const bad = (m: string, s = 400) => NextResponse.json({ error: m }, { status: s });

export async function POST(req: Request) {
  const u = await getUser();
  if (!u) return bad("Não autenticado.", 401);
  if (!has(u.role, "oficial")) return bad("Você não tem autorização para publicar.", 403);
  const b = await req.json().catch(() => null);
  const title = String(b?.title ?? "").trim().slice(0, 120), body = String(b?.body ?? "").trim().slice(0, 4000);
  const category = String(b?.category ?? "").trim().slice(0, 30) || "Atualização";
  const image = String(b?.image ?? "").trim();
  if (!title || !body) return bad("Preencha título e descrição.");
  if (image && !/^https:\/\/[^\s]+$/.test(image)) return bad("A imagem precisa ser um link https.");
  await query("INSERT INTO news(title,body,category,image_url,author_id) VALUES($1,$2,$3,$4,$5)", [title, body, category, image || null, u.id]);
  await query("INSERT INTO audit_log(actor_id,kind,description) VALUES($1,'config',$2)", [u.id, `Novidade publicada: ${title}`]);
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  const u = await getUser();
  if (!u || !has(u.role, "alto_comando")) return bad("Sem autorização.", 403);
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!Number.isInteger(id)) return bad("Publicação inválida.");
  await query("DELETE FROM news WHERE id=$1", [id]);
  return NextResponse.json({ ok: true });
}
