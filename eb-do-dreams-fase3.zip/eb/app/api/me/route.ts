import { NextResponse } from "next/server";
import { getUser } from "@/lib/session";
import { query } from "@/lib/db";
import { getAvatar } from "@/lib/roblox";

export async function GET() {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
  return NextResponse.json({ ...u, avatar: await getAvatar(Number(u.roblox_id)) });
}

export async function PUT(req: Request) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
  const body = await req.json().catch(() => null);
  const email = String(body?.email ?? "").trim().toLowerCase();
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 160)
    return NextResponse.json({ error: "Esse e-mail não parece válido." }, { status: 400 });
  await query("UPDATE users SET email = $1 WHERE id = $2", [email || null, u.id]);
  return NextResponse.json({ ok: true });
}
