import { NextResponse } from "next/server";
import { pool, query } from "@/lib/db";
import { getUser } from "@/lib/session";
import { has } from "@/lib/perm";

const bad = (m: string, s = 400) => NextResponse.json({ error: m }, { status: s });
const HEX = /^#[0-9a-fA-F]{6}$/;

export async function POST(req: Request) {
  const u = await getUser();
  if (!u) return bad("Não autenticado.", 401);
  if (!has(u.role, "alto_comando")) return bad("Só o Alto Comando pode alterar a hierarquia.", 403);
  const b = await req.json().catch(() => null);
  if (!b) return bad("Pedido inválido.");

  const log = (d: string) => query("INSERT INTO audit_log(actor_id,kind,description) VALUES($1,'config',$2)", [u.id, d]);
  const name = String(b.name ?? "").trim().slice(0, 80);
  const pos = Number.isInteger(Number(b.position)) ? Number(b.position) : 0;

  switch (b.action) {
    case "addCategory": {
      if (!name) return bad("Dê um nome à categoria.");
      const color = HEX.test(String(b.color)) ? String(b.color) : "#20F36B";
      await query("INSERT INTO rank_categories(name,color,position) VALUES($1,$2,$3)", [name, color, pos]);
      await log(`Categoria criada: ${name}`); break;
    }
    case "addRank": {
      const abbr = String(b.abbreviation ?? "").trim().slice(0, 12);
      const cat = Number(b.categoryId);
      if (!name || !abbr || !Number.isInteger(cat)) return bad("Informe categoria, nome e sigla.");
      const ok = await query("SELECT 1 FROM rank_categories WHERE id=$1", [cat]);
      if (!ok.length) return bad("Categoria não encontrada.", 404);
      await query("INSERT INTO ranks(category_id,name,abbreviation,position) VALUES($1,$2,$3,$4)", [cat, name, abbr, pos]);
      await log(`Patente criada: [${abbr}] ${name}`); break;
    }
    case "deleteRank": {
      const id = Number(b.id);
      const used = await query("SELECT 1 FROM users WHERE rank_id=$1 LIMIT 1", [id]);
      if (used.length) return bad("Há militares com essa patente. Mova-os antes de apagar.", 409);
      await query("DELETE FROM ranks WHERE id=$1", [id]); await log(`Patente apagada (id ${id})`); break;
    }
    case "deleteCategory": {
      const id = Number(b.id);
      const used = await query("SELECT 1 FROM ranks WHERE category_id=$1 LIMIT 1", [id]);
      if (used.length) return bad("A categoria ainda tem patentes. Apague-as primeiro.", 409);
      await query("DELETE FROM rank_categories WHERE id=$1", [id]); await log(`Categoria apagada (id ${id})`); break;
    }
    default: return bad("Ação desconhecida.");
  }
  return NextResponse.json({ ok: true });
}
