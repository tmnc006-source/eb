import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { query } from "@/lib/db";
import { newCode, sha256, token } from "@/lib/crypto";
import { clientIp, rateLimit } from "@/lib/rateLimit";
import { getProfile, RobloxError } from "@/lib/roblox";
import { cookieOpts, VF_COOKIE } from "@/lib/session";

const MINUTES = 30;

export async function POST(req: Request) {
  if (!rateLimit(`start:${clientIp(req)}`, 6, 10 * 60_000))
    return NextResponse.json({ error: "Muitos códigos gerados. Espere alguns minutos." }, { status: 429 });

  const body = await req.json().catch(() => null);
  const id = Number(body?.robloxId);
  if (!Number.isSafeInteger(id) || id <= 0) return NextResponse.json({ error: "Conta inválida." }, { status: 400 });

  try {
    const profile = await getProfile(id); // nome canônico vem do Roblox, não do navegador
    if (!profile) return NextResponse.json({ error: "Conta não encontrada." }, { status: 404 });

    const code = newCode();
    const challenge = token();
    const rows = await query<{ expires_at: string }>(
      `INSERT INTO verifications(roblox_id, roblox_username, code_hash, challenge_hash, expires_at)
       VALUES($1,$2,$3,$4, now() + ($5 || ' minutes')::interval) RETURNING expires_at`,
      [profile.id, profile.name, sha256(code), sha256(challenge), String(MINUTES)]
    );
    cookies().set(VF_COOKIE, challenge, cookieOpts(MINUTES * 60));
    return NextResponse.json({ code, expiresAt: rows[0].expires_at, name: profile.name });
  } catch (e) {
    if (e instanceof RobloxError) return NextResponse.json({ error: "Não conseguimos falar com o Roblox agora. Tente de novo." }, { status: 502 });
    return NextResponse.json({ error: "Erro interno." }, { status: 500 });
  }
}
