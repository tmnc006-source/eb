import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { query } from "@/lib/db";
import { extractCodes, safeEqual, sha256 } from "@/lib/crypto";
import { getAvatar, getProfile, RobloxError } from "@/lib/roblox";
import { createSession, cookieOpts, VF_COOKIE } from "@/lib/session";

type V = { id: string; roblox_id: string; roblox_username: string; code_hash: string; attempts: number };

export async function POST() {
  const challenge = cookies().get(VF_COOKIE)?.value;
  if (!challenge) return NextResponse.json({ error: "Sua verificação não foi encontrada. Comece de novo.", restart: true }, { status: 400 });

  const rows = await query<V>(
    `SELECT id, roblox_id::text, roblox_username, code_hash, attempts FROM verifications
      WHERE challenge_hash = $1 AND used_at IS NULL AND expires_at > now()`,
    [sha256(challenge)]
  );
  const v = rows[0];
  if (!v) return NextResponse.json({ error: "O código expirou. Gere um novo para continuar.", restart: true }, { status: 410 });
  if (v.attempts >= 15) return NextResponse.json({ error: "Tentativas demais com este código. Gere um novo.", restart: true }, { status: 429 });

  await query("UPDATE verifications SET attempts = attempts + 1 WHERE id = $1", [v.id]);

  try {
    const profile = await getProfile(Number(v.roblox_id));
    if (!profile) return NextResponse.json({ error: "Conta não encontrada no Roblox." }, { status: 404 });

    const found = extractCodes(profile.description).some((c) => safeEqual(sha256(c), v.code_hash));
    if (!found)
      return NextResponse.json({ error: "Não vimos o código na sua bio. Salve o campo Sobre e tente de novo (o Roblox pode levar alguns segundos)." }, { status: 422 });

    // marca como usado (impede reaproveitar o código)
    const used = await query("UPDATE verifications SET used_at = now() WHERE id = $1 AND used_at IS NULL RETURNING id", [v.id]);
    if (!used.length) return NextResponse.json({ error: "Este código já foi usado.", restart: true }, { status: 409 });

    const admins = (process.env.ADMIN_ROBLOX_IDS ?? "").split(",").map((s) => s.trim()).filter(Boolean);
    const role = admins.includes(v.roblox_id) ? "alto_comando" : "membro";
    const u = await query<{ id: string; role: string }>(
      `INSERT INTO users(roblox_id, roblox_username, display_name, role) VALUES($1,$2,$3,$4)
       ON CONFLICT (roblox_id) DO UPDATE SET roblox_username = EXCLUDED.roblox_username,
         display_name = EXCLUDED.display_name, verified_at = now(),
         role = CASE WHEN EXCLUDED.role = 'alto_comando' THEN 'alto_comando' ELSE users.role END
       RETURNING id, role`,
      [v.roblox_id, profile.name, profile.displayName, role]
    );
    await query("INSERT INTO audit_log(actor_id, target_user_id, kind, description) VALUES($1,$1,'sistema','Conta verificada pela bio do Roblox')", [u[0].id]);

    cookies().set(VF_COOKIE, "", cookieOpts(0));
    await createSession(u[0].id);
    return NextResponse.json({ ok: true, name: profile.name, avatar: await getAvatar(profile.id) });
  } catch (e) {
    if (e instanceof RobloxError) return NextResponse.json({ error: "Não conseguimos falar com o Roblox agora. Tente de novo." }, { status: 502 });
    return NextResponse.json({ error: "Erro interno." }, { status: 500 });
  }
}
