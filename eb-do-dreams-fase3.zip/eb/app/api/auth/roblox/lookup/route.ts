import { NextResponse } from "next/server";
import { clientIp, rateLimit } from "@/lib/rateLimit";
import { findByUsername, getAvatar, RobloxError, validUsername } from "@/lib/roblox";

export async function POST(req: Request) {
  if (!rateLimit(`lookup:${clientIp(req)}`, 12, 60_000))
    return NextResponse.json({ error: "Muitas buscas seguidas. Espere um minuto e tente de novo." }, { status: 429 });

  const body = await req.json().catch(() => null);
  const username = String(body?.username ?? "").trim().replace(/^@/, "");
  if (!validUsername(username))
    return NextResponse.json({ error: "Use o nome de usuário: de 3 a 20 letras, números ou _." }, { status: 400 });

  try {
    const user = await findByUsername(username);
    if (!user) return NextResponse.json({ error: "Não achamos esse nick no Roblox. Confira se não é o nome de exibição." }, { status: 404 });
    const avatar = await getAvatar(user.id);
    return NextResponse.json({ id: user.id, name: user.name, displayName: user.displayName, avatar });
  } catch (e) {
    const rate = e instanceof RobloxError && e.code === "rate";
    return NextResponse.json({ error: rate ? "O Roblox pediu um tempo. Tente de novo em instantes." : "Não conseguimos falar com o Roblox agora. Tente de novo." }, { status: 502 });
  }
}
