import { NextResponse } from "next/server";
import { pool } from "@/lib/db";
import { getUser } from "@/lib/session";
import { has } from "@/lib/perm";

const KINDS = ["promocao", "rebaixamento", "reversao", "ingresso"];
const LABEL: Record<string, string> = { promocao: "Promoção", rebaixamento: "Rebaixamento", reversao: "Reversão", ingresso: "Ingresso" };
const bad = (m: string, s = 400) => NextResponse.json({ error: m }, { status: s });

export async function POST(req: Request) {
  const me = await getUser();
  if (!me) return bad("Não autenticado.", 401);
  if (!has(me.role, "alto_comando")) return bad("Você não tem autorização para registrar movimentações.", 403);

  const b = await req.json().catch(() => null);
  const nick = String(b?.nick ?? "").trim().replace(/^@/, "");
  const rankId = Number(b?.rankId), kind = String(b?.kind ?? "");
  const reason = String(b?.reason ?? "").trim().slice(0, 300);
  if (!/^[A-Za-z0-9_]{3,20}$/.test(nick)) return bad("Nick inválido.");
  if (!Number.isInteger(rankId)) return bad("Escolha a nova patente.");
  if (!KINDS.includes(kind)) return bad("Tipo de movimentação inválido.");

  const c = await pool.connect();
  try {
    await c.query("BEGIN");
    const t = (await c.query("SELECT id, rank_id FROM users WHERE lower(roblox_username)=lower($1) FOR UPDATE", [nick])).rows[0];
    if (!t) { await c.query("ROLLBACK"); return bad("Esse militar ainda não entrou na plataforma (ele precisa se verificar primeiro).", 404); }
    if (t.id === me.id) { await c.query("ROLLBACK"); return bad("Você não pode alterar a própria patente.", 403); }
    const r = (await c.query("SELECT id, name, abbreviation FROM ranks WHERE id=$1", [rankId])).rows[0];
    if (!r) { await c.query("ROLLBACK"); return bad("Patente não encontrada.", 404); }

    await c.query("UPDATE users SET rank_id=$1 WHERE id=$2", [rankId, t.id]);
    await c.query("INSERT INTO rank_history(user_id,from_rank_id,to_rank_id,kind,reason,actor_id) VALUES($1,$2,$3,$4,$5,$6)", [t.id, t.rank_id, rankId, kind, reason || null, me.id]);
    await c.query("INSERT INTO audit_log(actor_id,target_user_id,kind,result,description) VALUES($1,$2,$3,'ok',$4)", [me.id, t.id, kind, `${LABEL[kind]} para [${r.abbreviation}] ${r.name}${reason ? `: ${reason}` : ""}`]);
    await c.query("INSERT INTO notifications(user_id,kind,title,body) VALUES($1,$2,$3,$4)", [t.id, kind, `${LABEL[kind]} registrada`, `Sua nova patente: [${r.abbreviation}] ${r.name}`]);
    await c.query("COMMIT");
    return NextResponse.json({ ok: true });
  } catch { await c.query("ROLLBACK").catch(() => {}); return bad("Erro interno.", 500); }
  finally { c.release(); }
}
