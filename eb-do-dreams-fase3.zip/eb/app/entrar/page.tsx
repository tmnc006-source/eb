import { redirect } from "next/navigation";
import { getUser } from "@/lib/session";
import Wizard from "@/components/Wizard";
import Emblem from "@/components/Emblem";

export default async function Entrar() {
  if (await getUser()) redirect("/inicio");
  return (
    <main className="mx-auto min-h-dvh max-w-xl px-5 pb-10">
      <header className="flex items-center gap-3 py-4">
        <Emblem size={34} /><span className="font-display text-xl font-bold">EB DO DREAMS</span>
      </header>
      <Wizard />
    </main>
  );
}
