/** Emblema próprio do EB DO DREAMS: escudo com três divisas e estrela. */
export default function Emblem({ size = 40, glow = true }: { size?: number; glow?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" role="img" aria-label="Emblema EB DO DREAMS"
      style={glow ? { filter: "drop-shadow(0 0 6px rgba(32,243,107,.55))" } : undefined}>
      <defs>
        <linearGradient id="eg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1b5a37" /><stop offset="1" stopColor="#0b2417" />
        </linearGradient>
      </defs>
      <path d="M32 4l24 8v18c0 15-10 25-24 30C18 55 8 45 8 30V12l24-8z" fill="url(#eg)" stroke="#20F36B" strokeWidth="2.2" />
      <path d="M32 11l2.3 4.9 5.3.6-4 3.6 1.1 5.3L32 22.7l-4.7 2.7 1.1-5.3-4-3.6 5.3-.6L32 11z" fill="#35FF83" transform="translate(0 -1)" />
      {[0, 8, 16].map((o) => (
        <path key={o} d={`M18 ${34 + o}l14-9 14 9`} fill="none" stroke="#35FF83" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" opacity={1 - o / 40} />
      ))}
    </svg>
  );
}
