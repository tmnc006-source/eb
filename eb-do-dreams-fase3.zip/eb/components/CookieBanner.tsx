"use client";
import { useEffect, useState } from "react";

const KEY = "eb_cookies";

export default function CookieBanner() {
  const [open, setOpen] = useState(false);
  const [config, setConfig] = useState(false);
  const [prefs, setPrefs] = useState(true);

  useEffect(() => { try { if (!localStorage.getItem(KEY)) setOpen(true); } catch { setOpen(true); } }, []);

  function save(choice: "all" | "essential" | "custom") {
    const value = choice === "all" ? { essential: true, preferences: true } : choice === "essential" ? { essential: true, preferences: false } : { essential: true, preferences: prefs };
    try { localStorage.setItem(KEY, JSON.stringify(value)); } catch {}
    setOpen(false);
  }
  if (!open) return null;

  return (
    <div role="dialog" aria-label="Uso de Cookies" className="fixed inset-x-0 bottom-[76px] z-[60] mx-auto max-w-xl px-3 lg:bottom-4">
      <div className="panel anim-page border-white/10 p-4 shadow-2xl">
        <h2 className="mb-1 text-lg font-bold">Uso de Cookies</h2>
        <p className="text-sm leading-snug text-mute">
          Utilizamos cookies essenciais para autenticação e segurança da sessão. Cookies de preferência armazenam configurações locais. Nenhum dado é vendido ou compartilhado com terceiros.
        </p>
        {config && (
          <div className="mt-3 space-y-2 text-sm">
            <label className="flex items-center justify-between rounded-xl bg-black/30 p-3"><span>Essenciais (sempre ativos)</span><input type="checkbox" checked disabled /></label>
            <label className="flex items-center justify-between rounded-xl bg-black/30 p-3"><span>Preferências locais</span>
              <input type="checkbox" checked={prefs} onChange={(e) => setPrefs(e.target.checked)} className="accent-[#20F36B]" /></label>
          </div>
        )}
        <div className="mt-3 flex flex-wrap items-center justify-end gap-2">
          {config
            ? <button className="btn btn-sm" onClick={() => save("custom")}>Salvar escolha</button>
            : <button className="btn-ghost btn-sm" onClick={() => setConfig(true)}>Configurar</button>}
          <button className="btn-ghost btn-sm !border-red-500/40 !bg-red-900/30" onClick={() => save("essential")}>Rejeitar não essenciais</button>
          <button className="btn btn-sm" onClick={() => save("all")}>Aceitar tudo</button>
        </div>
      </div>
    </div>
  );
}
