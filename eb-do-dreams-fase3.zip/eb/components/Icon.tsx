const P: Record<string, string> = {
  home: "M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10",
  user: "M12 12a4 4 0 100-8 4 4 0 000 8zM4 21c0-4 3.6-6 8-6s8 2 8 6",
  medal: "M12 15a6 6 0 100-12 6 6 0 000 12zM8.5 14L7 21l5-3 5 3-1.5-7",
  menu: "M4 7h16M4 12h16M4 17h16",
  bell: "M6 17V11a6 6 0 1112 0v6l2 2H4l2-2zM10 21h4",
  search: "M11 18a7 7 0 100-14 7 7 0 000 14zM21 21l-5-5",
  x: "M6 6l12 12M18 6L6 18",
  chev: "M6 9l6 6 6-6",
  right: "M9 6l6 6-6 6",
  download: "M12 4v11M7 10l5 5 5-5M5 20h14",
  copy: "M9 9h11v11H9zM5 15V4h11",
  check: "M5 12l5 5L20 6",
  checkc: "M12 21a9 9 0 100-18 9 9 0 000 18zM8 12l3 3 5-6",
  ext: "M14 4h6v6M20 4l-9 9M18 14v6H4V6h6",
  calendar: "M4 6h16v14H4zM4 10h16M8 3v4M16 3v4",
  chat: "M4 5h16v11H9l-5 4V5z",
  layers: "M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5",
  clipboard: "M9 4h6v3H9zM6 5h3M15 5h3v16H6V5M9 12h6M9 16h6",
  ticket: "M3 8a2 2 0 002-2h14a2 2 0 002 2v2a2 2 0 000 4v2a2 2 0 00-2 2H5a2 2 0 00-2-2v-2a2 2 0 000-4V8z",
  hourglass: "M7 3h10M7 21h10M8 3c0 5 8 5 8 9s-8 4-8 9M16 3c0 5-8 5-8 9",
  scroll: "M8 4h11v13a3 3 0 01-3 3H6a3 3 0 003-3V4H5v2M12 9h4M12 13h4",
  book: "M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2V5zM8 7h7",
  shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z",
  sparkles: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16z",
  bug: "M9 7a3 3 0 016 0v1H9V7zM7 10h10v4a5 5 0 01-10 0v-4zM3 12h4M17 12h4M4 6l3 2M20 6l-3 2M5 20l3-3M19 20l-3-3",
  logout: "M10 4H5v16h5M15 8l4 4-4 4M19 12H9",
  reload: "M20 12a8 8 0 11-2.6-5.9M20 4v5h-5",
  phone: "M8 2h8a1 1 0 011 1v18a1 1 0 01-1 1H8a1 1 0 01-1-1V3a1 1 0 011-1zM11 19h2",
  mail: "M3 6h18v12H3zM3 7l9 6 9-6",
  id: "M3 5h18v14H3zM7 10h4M7 14h6M15 9h3v5h-3z",
  info: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 11v6M12 7.5v.5",
  clock: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2"
};

export default function Icon({ name, size = 20, className = "" }: { name: string; size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9"
      strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d={P[name] ?? P.info} />
    </svg>
  );
}
