import Emblem from "./Emblem";
import Icon from "./Icon";

type Props = { avatar?: string | null; name?: string; code?: string; status: string; verified?: boolean };

export default function IdentityCard({ avatar, name, code, status, verified }: Props) {
  const parts = code ? code.split("-") : [];
  return (
    <div className="panel-neon overflow-hidden">
      <div className="flex items-center gap-3 bg-card/90 px-4 py-3">
        <Emblem size={34} glow={false} />
        <div className="leading-tight">
          <div className="font-display text-xl font-bold">Identidade do militar</div>
          <div className="text-xs text-mute">EB DO DREAMS, Exército Brasileiro no Roblox</div>
        </div>
      </div>
      <div className="flex gap-4 bg-[#eef3ee] p-4 text-[#0c1a12]">
        <div className="relative h-28 w-28 shrink-0 overflow-hidden rounded-xl border-2 border-neon bg-[#1a2620]">
          {avatar ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={avatar} alt={`Avatar de ${name}`} className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-mute"><Icon name="user" size={40} /></div>}
          {verified && <div className="anim-pop absolute inset-0 grid place-items-center bg-black/35"><div className="grid h-16 w-16 place-items-center rounded-full bg-neon text-ink shadow-neon"><Icon name="check" size={34} /></div></div>}
        </div>
        <div className="min-w-0 flex-1 text-sm">
          <div className="dashed pb-1"><div className="text-[11px] text-[#4b5a50]">Nick no Roblox</div><div className="truncate font-display text-xl font-bold">{name ? `@${name}` : "aparece no passo 1"}</div></div>
          <div className="dashed py-1"><div className="text-[11px] text-[#4b5a50]">Código da bio</div>
            {parts.length ? <div className="mt-1 flex flex-wrap gap-1">{parts.map((p, i) => <span key={i} className="chip !py-0 text-sm">{p}</span>)}</div> : <div className="text-[#6b7a70]">aparece no passo 2</div>}
          </div>
          <div className="flex items-center gap-1 pt-2 text-xs font-semibold text-[#14803f]"><Icon name={verified ? "checkc" : "clock"} size={14} /> {status}</div>
        </div>
      </div>
    </div>
  );
}
