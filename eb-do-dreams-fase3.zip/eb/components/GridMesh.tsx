/** Malha digital em perspectiva usada no rodapé da tela de identificação. */
export default function GridMesh() {
  const lines: JSX.Element[] = [];
  for (let i = -12; i <= 12; i++) lines.push(<line key={`v${i}`} x1={200 + i * 14} y1="40" x2={200 + i * 52} y2="260" />);
  for (let j = 0; j < 9; j++) { const y = 40 + Math.pow(j / 8, 1.8) * 220; lines.push(<line key={`h${j}`} x1="-60" y1={y} x2="460" y2={y} />); }
  return (
    <svg viewBox="0 0 400 260" preserveAspectRatio="xMidYMax slice" className="pointer-events-none absolute inset-x-0 bottom-0 h-[42%] w-full" aria-hidden="true">
      <defs>
        <linearGradient id="gm" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#20F36B" stopOpacity="0" /><stop offset="1" stopColor="#20F36B" stopOpacity=".9" /></linearGradient>
        <mask id="mk"><rect width="400" height="260" fill="url(#gm)" /></mask>
      </defs>
      <g stroke="#35FF83" strokeWidth="1" mask="url(#mk)">{lines}</g>
    </svg>
  );
}
