"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

async function send(url: string, method: string, body?: unknown) {
  const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, error: data.error as string | undefined };
}

function Msg({ m }: { m: string }) { return m ? <p role="alert" className="mt-2 rounded-lg border border-red-500/40 bg-red-950/50 p-2 text-sm text-red-200">{m}</p> : null; }

type Cat = { id: number; name: string };

export function HierarchyAdmin({ cats }: { cats: Cat[] }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [err, setErr] = useState("");
  const [cat, setCat] = useState({ name: "", color: "#20F36B", position: "0" });
  const [rank, setRank] = useState({ categoryId: cats[0] ? String(cats[0].id) : "", name: "", abbreviation: "", position: "0" });

  async function run(body: unknown, after?: () => void) {
    setErr("");
    const r = await send("/api/hierarchy", "POST", body);
    if (!r.ok) return setErr(r.error ?? "Não foi possível salvar.");
    after?.(); router.refresh();
  }
  if (!open) return <button className="btn-ghost btn-sm" onClick={() => setOpen(true)}>Gerenciar hierarquia</button>;
  return (
    <div className="panel space-y-5 p-4">
      <div className="flex items-center justify-between"><h3 className="font-display text-xl font-bold">Gerenciar hierarquia</h3><button className="text-sm underline" onClick={() => setOpen(false)}>Fechar</button></div>
      <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); run({ action: "addCategory", ...cat }, () => setCat({ ...cat, name: "" })); }}>
        <h4 className="font-semibold">Nova categoria</h4>
        <input className="input" placeholder="Nome da categoria" value={cat.name} onChange={(e) => setCat({ ...cat, name: e.target.value })} />
        <div className="flex gap-2"><input type="color" aria-label="Cor" className="h-11 w-14 rounded-lg bg-transparent" value={cat.color} onChange={(e) => setCat({ ...cat, color: e.target.value })} />
          <input className="input" inputMode="numeric" placeholder="Posição (maior = mais alto)" value={cat.position} onChange={(e) => setCat({ ...cat, position: e.target.value })} /></div>
        <button className="btn btn-sm">Criar categoria</button>
      </form>
      <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); run({ action: "addRank", ...rank }, () => setRank({ ...rank, name: "", abbreviation: "" })); }}>
        <h4 className="font-semibold">Nova patente</h4>
        <select className="input" value={rank.categoryId} onChange={(e) => setRank({ ...rank, categoryId: e.target.value })}>
          {cats.length === 0 && <option value="">Crie uma categoria primeiro</option>}{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <input className="input" placeholder="Nome da patente" value={rank.name} onChange={(e) => setRank({ ...rank, name: e.target.value })} />
        <div className="flex gap-2"><input className="input" placeholder="Sigla" value={rank.abbreviation} onChange={(e) => setRank({ ...rank, abbreviation: e.target.value })} />
          <input className="input" inputMode="numeric" placeholder="Posição" value={rank.position} onChange={(e) => setRank({ ...rank, position: e.target.value })} /></div>
        <button className="btn btn-sm" disabled={!cats.length}>Criar patente</button>
      </form>
      <Msg m={err} />
    </div>
  );
}

export function DeleteBtn({ kind, id }: { kind: "Rank" | "Category"; id: number }) {
  const router = useRouter();
  const [err, setErr] = useState("");
  return (
    <>
      <button className="text-xs text-red-300 underline" aria-label="Apagar" onClick={async () => {
        if (!confirm("Apagar este item?")) return;
        const r = await send("/api/hierarchy", "POST", { action: `delete${kind}`, id });
        if (!r.ok) setErr(r.error ?? "Erro"); else router.refresh();
      }}>apagar</button>{err && <span className="ml-2 text-xs text-red-300">{err}</span>}
    </>
  );
}

export function RankChangeForm({ ranks, nick }: { ranks: { id: number; label: string }[]; nick: string }) {
  const router = useRouter();
  const [f, setF] = useState({ nick, rankId: "", kind: "promocao", reason: "" });
  const [err, setErr] = useState(""); const [ok, setOk] = useState(false); const [busy, setBusy] = useState(false);
  return (
    <form className="panel space-y-2 p-4" onSubmit={async (e) => {
      e.preventDefault(); setErr(""); setOk(false); setBusy(true);
      const r = await send("/api/rank-change", "POST", { ...f, rankId: Number(f.rankId) });
      setBusy(false);
      if (!r.ok) return setErr(r.error ?? "Não foi possível registrar.");
      setOk(true); router.refresh();
    }}>
      <h3 className="font-display text-xl font-bold">Registrar movimentação</h3>
      <input className="input" placeholder="@nick do militar" value={f.nick} onChange={(e) => setF({ ...f, nick: e.target.value })} />
      <select className="input" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>
        <option value="promocao">Promoção</option><option value="rebaixamento">Rebaixamento</option><option value="reversao">Reversão</option><option value="ingresso">Ingresso</option></select>
      <select className="input" value={f.rankId} onChange={(e) => setF({ ...f, rankId: e.target.value })} required>
        <option value="">Nova patente</option>{ranks.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}</select>
      <input className="input" placeholder="Motivo" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} maxLength={300} />
      <button className="btn btn-sm" disabled={busy}>{busy && <span className="spinner" />} Registrar</button>
      {ok && <p role="status" className="text-sm text-glow">Movimentação registrada.</p>}
      <Msg m={err} />
    </form>
  );
}

export function NewsForm() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ title: "", category: "Atualização", body: "", image: "" });
  const [err, setErr] = useState("");
  if (!open) return <button className="btn btn-sm" onClick={() => setOpen(true)}>Publicar novidade</button>;
  return (
    <form className="panel space-y-2 p-4" onSubmit={async (e) => {
      e.preventDefault(); setErr("");
      const r = await send("/api/news", "POST", f);
      if (!r.ok) return setErr(r.error ?? "Não foi possível publicar.");
      setF({ title: "", category: "Atualização", body: "", image: "" }); setOpen(false); router.refresh();
    }}>
      <input className="input" placeholder="Título" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} maxLength={120} />
      <input className="input" placeholder="Categoria (ex.: Treino, Aviso)" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} maxLength={30} />
      <textarea className="input min-h-28" placeholder="Descrição" value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} />
      <input className="input" placeholder="Link da imagem (opcional, https)" value={f.image} onChange={(e) => setF({ ...f, image: e.target.value })} />
      <div className="flex gap-2"><button className="btn btn-sm">Publicar</button><button type="button" className="btn-ghost btn-sm" onClick={() => setOpen(false)}>Cancelar</button></div>
      <Msg m={err} />
    </form>
  );
}

export function DeleteNews({ id }: { id: number }) {
  const router = useRouter();
  return <button className="text-xs text-red-300 underline" onClick={async () => { if (!confirm("Apagar esta publicação?")) return; const r = await send(`/api/news?id=${id}`, "DELETE"); if (r.ok) router.refresh(); }}>apagar</button>;
}
