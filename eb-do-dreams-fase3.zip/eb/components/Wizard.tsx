"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "./Icon";
import IdentityCard from "./IdentityCard";

type Found = { id: number; name: string; displayName: string; avatar: string | null };
type Step = "nick" | "confirm" | "code" | "done";
const SS = "eb_verify_state";

export default function Wizard() {
  const router = useRouter();
  const [step, setStep] = useState<Step>("nick");
  const [nick, setNick] = useState("");
  const [found, setFound] = useState<Found | null>(null);
  const [code, setCode] = useState("");
  const [expiresAt, setExpiresAt] = useState(0);
  const [left, setLeft] = useState(0);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState(false);
  const [progress, setProgress] = useState(0);
  const verifyRef = useRef(false);

  // retoma o passo 2 se a página for recarregada antes de expirar
  useEffect(() => {
    try {
      const s = JSON.parse(sessionStorage.getItem(SS) || "null");
      if (s && s.expiresAt > Date.now()) { setFound(s.found); setCode(s.code); setExpiresAt(s.expiresAt); setStep("code"); }
    } catch {}
  }, []);

  useEffect(() => {
    if (step !== "code") return;
    const t = setInterval(() => setLeft(Math.max(0, expiresAt - Date.now())), 500);
    setLeft(Math.max(0, expiresAt - Date.now()));
    return () => clearInterval(t);
  }, [step, expiresAt]);

  useEffect(() => {
    if (step !== "done") return;
    const t = setInterval(() => setProgress((p) => Math.min(100, p + 4)), 90);
    const go = setTimeout(() => router.replace("/inicio"), 2600);
    return () => { clearInterval(t); clearTimeout(go); };
  }, [step, router]);

  async function post(url: string, body?: unknown) {
    const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    const data = await res.json().catch(() => ({}));
    return { ok: res.ok, data };
  }

  async function search() {
    setErr(""); setBusy(true);
    const { ok, data } = await post("/api/auth/roblox/lookup", { username: nick });
    setBusy(false);
    if (!ok) return setErr(data.error ?? "Não foi possível buscar agora.");
    setFound(data); setStep("confirm");
  }

  async function confirmMine() {
    if (!found) return;
    setErr(""); setBusy(true);
    const { ok, data } = await post("/api/auth/roblox/start", { robloxId: found.id });
    setBusy(false);
    if (!ok) return setErr(data.error ?? "Não foi possível gerar o código.");
    const exp = new Date(data.expiresAt).getTime();
    setCode(data.code); setExpiresAt(exp); setStep("code");
    try { sessionStorage.setItem(SS, JSON.stringify({ found, code: data.code, expiresAt: exp })); } catch {}
  }

  const verify = useCallback(async () => {
    if (verifyRef.current) return;
    verifyRef.current = true; setErr(""); setBusy(true);
    const { ok, data } = await post("/api/auth/roblox/verify");
    setBusy(false); verifyRef.current = false;
    if (!ok) {
      if (data.restart) { try { sessionStorage.removeItem(SS); } catch {} setStep("nick"); }
      return setErr(data.error ?? "Não foi possível verificar agora.");
    }
    try { sessionStorage.removeItem(SS); } catch {}
    setFound((f) => (f ? { ...f, name: data.name, avatar: data.avatar ?? f.avatar } : f));
    setStep("done");
  }, []);

  async function copy() {
    try { await navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); }
    catch { setErr("Não deu para copiar sozinho. Selecione o código e copie manualmente."); }
  }

  const mm = String(Math.floor(left / 60000)).padStart(2, "0");
  const ss = String(Math.floor((left % 60000) / 1000)).padStart(2, "0");
  const expired = step === "code" && left === 0 && expiresAt > 0;
  const n = step === "nick" || step === "confirm" ? 1 : step === "code" ? 2 : 3;
  const labels = ["Achar a sua conta", "Colar o código na bio", "Pronto"];

  return (
    <div className="anim-page">
      <div className="mb-3 flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-mil text-glow"><Icon name={n === 3 ? "checkc" : n === 2 ? "copy" : "search"} /></span>
        <div className="leading-tight"><div className="text-xs text-mute">Passo {n} de 3</div><div className="font-semibold">{step === "done" ? "Conta verificada" : labels[n - 1]}</div></div>
      </div>
      <h1 className="mb-4 font-display text-5xl font-bold leading-[.95]">Prove que a conta é sua.</h1>

      <IdentityCard avatar={found?.avatar} name={found?.name} code={step === "code" || step === "done" ? code : undefined}
        verified={step === "done"}
        status={step === "done" ? "Verificado hoje" : step === "code" ? "Esperando o código na bio" : step === "confirm" ? "Confirme se a conta é sua" : "Esperando o seu nick"} />

      {step === "nick" && (
        <form className="mt-6" onSubmit={(e) => { e.preventDefault(); search(); }}>
          <h2 className="font-display text-2xl font-bold">Qual é o seu nick no Roblox?</h2>
          <label htmlFor="nick" className="mt-2 block text-sm font-semibold">Nick no Roblox</label>
          <div className="mt-1 flex gap-2">
            <div className="relative flex-1"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-mute">@</span>
              <input id="nick" className="input !pl-8" placeholder="SoldadoDreams" autoCapitalize="none" autoCorrect="off" autoComplete="off" value={nick} onChange={(e) => setNick(e.target.value)} /></div>
            <button className="btn" disabled={busy || nick.trim().length < 3}>{busy ? <span className="spinner" /> : <Icon name="search" />} Buscar</button>
          </div>
          <p className="mt-2 text-sm text-mute">É o nome com @ que aparece no seu perfil, não o apelido.</p>
        </form>
      )}

      {step === "confirm" && found && (
        <div className="mt-6">
          <h2 className="font-display text-2xl font-bold">É você, @{found.name}?</h2>
          <p className="mt-1 text-sm text-mute">Confira se a foto é a do seu avatar. ID Roblox: {found.id}</p>
          <div className="mt-3 flex flex-wrap items-center gap-4">
            <button className="btn" onClick={confirmMine} disabled={busy}>{busy ? <span className="spinner" /> : <Icon name="check" />} Sim, sou eu</button>
            <button className="text-sm underline" onClick={() => { setStep("nick"); setFound(null); setErr(""); }}>Não, buscar outro nick</button>
          </div>
        </div>
      )}

      {step === "code" && (
        <div className="mt-6">
          <h2 className="font-display text-2xl font-bold">Cole este código na sua bio</h2>
          <div className="mt-3 flex flex-wrap items-center gap-2" aria-label="Código de verificação">
            {code.split("-").map((p, i, a) => <span key={i} className="flex items-center gap-2"><span className="chip text-xl">{p}</span>{i < a.length - 1 && <span className="text-mute">-</span>}</span>)}
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <button className="btn-ghost" onClick={copy}><Icon name="copy" size={18} /> Copiar código</button>
            {copied && <span className="flex items-center gap-1 text-sm text-glow"><Icon name="check" size={16} /> Copiado</span>}
          </div>
          <p className={`mt-3 flex items-center gap-2 text-sm ${expired ? "text-red-400" : "text-mute"}`}>
            <Icon name="clock" size={16} /> {expired ? "O código expirou." : <>Vale por <b className="text-snow">{mm}:{ss}</b></>}
          </p>
          <ol className="mt-4 space-y-3 text-[15px]">
            {[<>Abra o Roblox e entre no <b>seu perfil</b>. <a className="font-semibold text-glow underline" target="_blank" rel="noopener noreferrer" href={`https://www.roblox.com/users/${found?.id}/profile`}>Abrir meu perfil <Icon name="ext" size={13} className="inline" /></a></>,
              <>Toque em <b>Editar perfil</b> e cole o código no campo <b>Sobre</b>.</>, <>Toque em <b>Salvar</b> e volte aqui.</>].map((t, i) => (
              <li key={i} className="flex gap-3"><span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-neon font-bold text-ink">{i + 1}</span><span>{t}</span></li>))}
          </ol>
          {expired
            ? <button className="btn mt-5 w-full" onClick={confirmMine} disabled={busy}>Gerar novo código</button>
            : <button className="btn mt-5 w-full" onClick={verify} disabled={busy}>{busy ? <span className="spinner" /> : <Icon name="checkc" />} Já coloquei, verificar</button>}
        </div>
      )}

      {step === "done" && found && (
        <div className="mt-6" role="status">
          <h2 className="font-display text-3xl font-bold">Tudo certo, @{found.name}!</h2>
          <p className="mt-1 text-mute">A conta é sua. Abrindo o painel...</p>
          <div className="mt-3 h-3 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-neon shadow-[0_0_12px_#20F36B] transition-[width] duration-100" style={{ width: `${progress}%` }} /></div>
          <p className="mt-3 text-sm text-mute">Depois você já pode apagar o código da sua bio.</p>
        </div>
      )}

      {err && <p role="alert" className="mt-4 rounded-xl border border-red-500/40 bg-red-950/50 p-3 text-sm text-red-200">{err}</p>}
    </div>
  );
}
