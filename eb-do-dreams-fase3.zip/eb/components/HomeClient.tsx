"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import Icon from "./Icon";
import Emblem from "./Emblem";

const STEPS = [
  { icon: "menu", title: "O menu", text: "Toque em Menu (ou nas três linhas) para abrir a navegação. No computador ele fica sempre visível à esquerda." },
  { icon: "search", title: "Atalhos e busca", text: "No topo do menu ficam os atalhos para Entregar, CDP, Registro e Códigos. O campo “Para onde vamos?” encontra qualquer página." },
  { icon: "home", title: "O painel inicial", text: "O Início reúne avisos e o guia de cada ferramenta. O sino mostra suas notificações e o botão App instala o painel no celular." },
  { icon: "medal", title: "Sua carreira", text: "Em Patente e Histórico de Patentes você acompanha a patente atual e cada promoção ou rebaixamento registrado." },
  { icon: "shield", title: "Ferramentas de comando", text: "Quem tem autorização usa Entregar Patente e Patentes nas Divisões. Toda ação fica registrada com o nome do responsável." }
];

export function FirstAccessNotice() {
  const [hidden, setHidden] = useState(true);
  useEffect(() => { try { setHidden(localStorage.getItem("eb_notice_email") === "1"); } catch { setHidden(false); } }, []);
  if (hidden) return null;
  return (
    <div className="panel relative mb-5 border-white/20 p-4 pr-10">
      <button className="absolute right-3 top-3 text-mute" aria-label="Fechar aviso" onClick={() => { try { localStorage.setItem("eb_notice_email", "1"); } catch {} setHidden(true); }}><Icon name="x" size={18} /></button>
      <div className="flex gap-3"><Icon name="mail" className="mt-1 shrink-0 text-mute" />
        <p className="text-sm leading-snug"><b>Cadastre seu e-mail.</b> Se um dia você perder o acesso, é por ele que a gente recupera sua conta. E você fica sabendo na hora quando for promovido.</p></div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Link href="/perfil" className="btn btn-sm"><Icon name="mail" size={16} /> Cadastrar e-mail</Link>
        <Link href="/em-breve/discord" className="btn-ghost btn-sm">Ligar meu Discord</Link>
      </div>
    </div>
  );
}

export function Hero() {
  const [open, setOpen] = useState(false);
  const [i, setI] = useState(0);
  const s = STEPS[i];
  return (
    <>
      <section className="panel-neon p-5">
        <div className="mb-3 flex items-center gap-2"><Emblem size={26} glow={false} /><span className="chip !text-xs">EB DO DREAMS</span></div>
        <h2 className="font-display text-4xl font-bold leading-[.95]">O quartel inteiro num painel só.</h2>
        <p className="mt-3 text-[15px] leading-relaxed text-mute">O sistema oficial de gestão militar do Exército Brasileiro do Dreams no Roblox: promoções, rebaixamentos, relatórios de treinamento, hierarquia e registro de cada ação, com segurança e organização para o Alto Comando e os instrutores.</p>
        <button className="btn mt-4" onClick={() => { setI(0); setOpen(true); }}><Icon name="sparkles" size={18} /> Fazer o tutorial</button>
      </section>

      {open && (
        <div className="fixed inset-0 z-[70] grid place-items-center bg-black/75 p-5" role="dialog" aria-modal="true" aria-label="Tutorial">
          <div className="panel-neon anim-pop w-full max-w-sm p-5">
            <div className="flex items-center justify-between text-xs text-mute"><span>Passo {i + 1} de {STEPS.length}</span>
              <button onClick={() => setOpen(false)} className="underline">Sair do tutorial</button></div>
            <div className="my-4 grid h-14 w-14 place-items-center rounded-2xl bg-mil text-glow"><Icon name={s.icon} size={28} /></div>
            <h3 className="font-display text-3xl font-bold">{s.title}</h3>
            <p className="mt-2 text-[15px] leading-relaxed text-mute">{s.text}</p>
            <div className="mt-3 flex gap-1.5">{STEPS.map((_, k) => <span key={k} className={`h-1.5 flex-1 rounded ${k <= i ? "bg-neon" : "bg-white/15"}`} />)}</div>
            <div className="mt-4 flex justify-between gap-2">
              <button className="btn-ghost" disabled={i === 0} onClick={() => setI(i - 1)}>Voltar</button>
              {i < STEPS.length - 1 ? <button className="btn" onClick={() => setI(i + 1)}>Avançar</button> : <button className="btn" onClick={() => setOpen(false)}>Concluir</button>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
