"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import Icon from "./Icon";
import Emblem from "./Emblem";
import { ALL_ITEMS, HOME, SECTIONS, SHORTCUTS, TITLES, type NavItem } from "@/lib/nav";

type U = { name: string; avatar: string | null; rank: string | null; division: string | null };

export default function Shell({ user, children }: { user: U; children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const [drawer, setDrawer] = useState(false);
  const [bell, setBell] = useState(false);
  const [install, setInstall] = useState(false);
  const [deferred, setDeferred] = useState<any>(null);

  useEffect(() => { setDrawer(false); setBell(false); }, [path]);
  useEffect(() => {
    const h = (e: Event) => { e.preventDefault(); setDeferred(e); };
    window.addEventListener("beforeinstallprompt", h);
    return () => window.removeEventListener("beforeinstallprompt", h);
  }, []);
  useEffect(() => { document.body.style.overflow = drawer ? "hidden" : ""; }, [drawer]);

  const title = TITLES[path] ?? (path.startsWith("/em-breve/") ? ALL_ITEMS.find((i) => i.href === path)?.label ?? "Em breve" : "EB DO DREAMS");

  async function doInstall() {
    if (deferred) { deferred.prompt(); await deferred.userChoice.catch(() => {}); setDeferred(null); }
    else setInstall(true);
  }
  async function logout() { await fetch("/api/auth/logout", { method: "POST" }); router.replace("/"); router.refresh(); }

  return (
    <div className="min-h-dvh lg:pl-[300px]">
      <aside className="fixed inset-y-0 left-0 hidden w-[300px] border-r border-white/5 bg-[#0b120e]/95 lg:block">
        <Menu user={user} onLogout={logout} onInstall={doInstall} />
      </aside>

      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <button className="absolute inset-0 bg-black/65" aria-label="Fechar menu" onClick={() => setDrawer(false)} />
          <div className="anim-drawer absolute inset-y-0 left-0 w-[72vw] min-w-[290px] max-w-[380px] border-r border-neon/40 bg-[#0e1612] shadow-[0_0_40px_rgba(32,243,107,.15)]">
            <Menu user={user} onClose={() => setDrawer(false)} onLogout={logout} onInstall={() => { setDrawer(false); doInstall(); }} />
          </div>
        </div>
      )}

      <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-white/5 bg-[#0a110d]/90 px-3 py-2.5 pt-[max(.6rem,env(safe-area-inset-top))] backdrop-blur">
        <button className="grid h-10 w-10 place-items-center rounded-xl hover:bg-white/5 lg:hidden" onClick={() => setDrawer(true)} aria-label="Abrir menu"><Icon name="menu" /></button>
        <h1 className="flex-1 truncate font-display text-xl font-semibold">{title}</h1>
        <button className="btn btn-sm !py-1.5" onClick={doInstall}><Icon name="download" size={16} /> App</button>
        <div className="relative">
          <button className="relative grid h-10 w-10 place-items-center rounded-xl hover:bg-white/5" onClick={() => setBell((b) => !b)} aria-label="Notificações" aria-expanded={bell}><Icon name="bell" /></button>
          {bell && (
            <div className="anim-page panel absolute right-0 top-12 z-50 w-72 p-4 shadow-2xl">
              <div className="mb-1 font-display text-lg font-bold">Notificações</div>
              <p className="text-sm text-mute">Nenhum aviso por enquanto. Promoções, treinos e comunicados vão aparecer aqui.</p>
            </div>
          )}
        </div>
      </header>

      <main key={path} className="anim-page mx-auto w-full max-w-3xl px-4 pb-32 pt-4 lg:pb-12">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/5 bg-[#0a110d]/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden" aria-label="Principal">
        <ul className="mx-auto grid max-w-xl grid-cols-4">
          {[{ href: "/inicio", icon: "home", label: "Início" }, { href: "/perfil", icon: "user", label: "Perfil" }, { href: "/patente", icon: "medal", label: "Patente" }].map((t) => {
            const on = path === t.href;
            return (
              <li key={t.href}><Link href={t.href} className={`relative flex flex-col items-center gap-0.5 py-2.5 text-xs ${on ? "text-glow" : "text-mute"}`} aria-current={on ? "page" : undefined}>
                {on && <span className="absolute -top-px h-[3px] w-10 rounded-b bg-neon shadow-[0_0_10px_#20F36B]" />}
                <Icon name={t.icon} /><span>{t.label}</span></Link></li>
            );
          })}
          <li><button className={`flex w-full flex-col items-center gap-0.5 py-2.5 text-xs ${drawer ? "text-glow" : "text-mute"}`} onClick={() => setDrawer(true)}><Icon name="menu" /><span>Menu</span></button></li>
        </ul>
      </nav>

      {install && (
        <div className="fixed inset-0 z-[70] grid place-items-center bg-black/70 p-5" role="dialog" aria-modal="true">
          <div className="panel-neon anim-pop w-full max-w-sm p-5">
            <h2 className="font-display text-2xl font-bold">Instalar o app</h2>
            <p className="mt-2 text-sm text-mute">Seu navegador não abriu a instalação automática. Faça assim:</p>
            <ul className="mt-3 space-y-2 text-sm">
              <li><b>iPhone (Safari):</b> toque em Compartilhar e em &quot;Adicionar à Tela de Início&quot;.</li>
              <li><b>Android (Chrome):</b> abra o menu ⋮ e toque em &quot;Instalar app&quot;.</li>
              <li><b>Computador (Chrome/Edge):</b> use o ícone de instalar na barra de endereço.</li>
            </ul>
            <button className="btn mt-4 w-full" onClick={() => setInstall(false)}>Entendi</button>
          </div>
        </div>
      )}
    </div>
  );
}

function Menu({ user, onClose, onLogout, onInstall }: { user: U; onClose?: () => void; onLogout: () => void; onInstall: () => void }) {
  const path = usePathname();
  const [q, setQ] = useState("");
  const [closed, setClosed] = useState<Record<string, boolean>>({});
  const results = useMemo(() => {
    const t = q.trim().toLowerCase();
    return t ? ALL_ITEMS.filter((i) => i.label.toLowerCase().includes(t)) : [];
  }, [q]);

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 border-b border-dashed border-neon/40 px-4 py-3 pt-[max(.75rem,env(safe-area-inset-top))]">
        <Emblem size={36} /><span className="flex-1 font-display text-xl font-bold">EB DO DREAMS</span>
        {onClose && <button onClick={onClose} aria-label="Fechar menu" className="grid h-9 w-9 place-items-center rounded-lg text-mute hover:bg-white/5"><Icon name="x" /></button>}
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto overscroll-contain px-3 py-3">
        <Link href="/perfil" className="flex items-center gap-3 rounded-2xl border border-neon/40 bg-card/80 p-2.5">
          <span className="h-11 w-11 overflow-hidden rounded-lg border border-neon/60 bg-black">{user.avatar && /* eslint-disable-next-line @next/next/no-img-element */ <img src={user.avatar} alt="" className="h-full w-full object-cover" />}</span>
          <span className="min-w-0 leading-tight"><span className="block truncate font-display text-lg font-bold">{user.name}</span><span className="block truncate text-xs text-mute">{user.rank ?? "Sem patente registrada"}{user.division ? ` · ${user.division}` : ""}</span></span>
        </Link>

        <label className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-mute focus-within:border-neon/60">
          <Icon name="search" size={18} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Para onde vamos?" className="w-full bg-transparent text-snow outline-none placeholder:text-mute" aria-label="Pesquisar página" />
        </label>

        {q.trim() ? (
          <div className="space-y-1">
            {results.length ? results.map((i) => <Row key={i.href} item={i} on={path === i.href} />) : <p className="px-2 text-sm text-mute">Nada encontrado para &quot;{q}&quot;.</p>}
          </div>
        ) : (
          <>
            <div>
              <div className="mb-2 px-1 text-xs font-bold text-glow">Atalhos</div>
              <div className="grid grid-cols-4 gap-2">
                {SHORTCUTS.map((s) => (
                  <Link key={s.slug} href={s.href} className="flex flex-col items-center gap-1 rounded-xl border border-neon/30 bg-card py-2 text-[11px] hover:border-neon">
                    <span className="text-glow"><Icon name={s.icon} size={18} /></span>{s.label}
                  </Link>))}
              </div>
            </div>
            <Row item={HOME} on={path === HOME.href} />
            {SECTIONS.map((s) => {
              const shut = closed[s.title];
              return (
                <div key={s.title}>
                  <button className="mb-2 flex w-full items-center justify-between px-1 text-xs font-bold text-glow" onClick={() => setClosed((c) => ({ ...c, [s.title]: !c[s.title] }))} aria-expanded={!shut}>
                    {s.title}<Icon name="chev" size={16} className={`transition-transform ${shut ? "-rotate-90" : ""}`} />
                  </button>
                  {!shut && <div className="grid grid-cols-3 gap-2">{s.items.map((i) => (
                    <Link key={i.href + i.label} href={i.href} className={`flex flex-col items-center gap-1.5 rounded-xl border bg-card px-1 py-3 text-center text-[11px] leading-tight ${path === i.href ? "border-neon shadow-neon" : "border-white/5"}`}>
                      <Icon name={i.icon} size={20} />{i.label}</Link>))}</div>}
                </div>);
            })}
          </>
        )}
      </div>

      <div className="border-t border-dashed border-neon/40 p-3">
        <button onClick={onInstall} className="flex w-full items-center gap-3 rounded-xl border border-neon/50 bg-mil/50 p-2.5 text-left">
          <span className="grid h-10 w-10 place-items-center rounded-lg bg-neon text-ink"><Icon name="phone" /></span>
          <span className="leading-tight"><b className="block text-glow">Baixar o app</b><span className="text-xs text-mute">Ícone na tela e aviso da patente na hora</span></span>
        </button>
        <div className="mt-3 flex justify-around">
          <button className="grid h-9 w-9 place-items-center rounded-full text-mute hover:bg-white/5" onClick={() => location.reload()} aria-label="Atualizar"><Icon name="reload" size={18} /></button>
          <button className="grid h-9 w-9 place-items-center rounded-full text-mute hover:bg-white/5" onClick={onLogout} aria-label="Sair da conta"><Icon name="logout" size={18} /></button>
        </div>
      </div>
    </div>
  );
}

function Row({ item, on }: { item: NavItem; on: boolean }) {
  return (
    <Link href={item.href} className={`flex items-center gap-3 rounded-xl border px-3 py-2.5 ${on ? "border-neon bg-mil/40 text-glow" : "border-white/5 bg-card"}`}>
      <Icon name={item.icon} size={18} /><span className="font-semibold">{item.label}</span>
    </Link>
  );
}
