"use client";
import { useState } from "react";

export default function EmailForm({ initial }: { initial: string }) {
  const [email, setEmail] = useState(initial);
  const [state, setState] = useState<"idle" | "saving" | "ok" | "err">("idle");
  const [msg, setMsg] = useState("");

  async function save(e: React.FormEvent) {
    e.preventDefault(); setState("saving");
    const res = await fetch("/api/me", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
    const data = await res.json().catch(() => ({}));
    if (res.ok) { setState("ok"); setMsg("E-mail salvo."); } else { setState("err"); setMsg(data.error ?? "Não foi possível salvar."); }
  }
  return (
    <form onSubmit={save} className="space-y-2">
      <label htmlFor="email" className="text-sm font-semibold">E-mail de recuperação</label>
      <input id="email" type="email" className="input" placeholder="voce@exemplo.com" value={email} onChange={(e) => { setEmail(e.target.value); setState("idle"); }} autoComplete="email" />
      <div className="flex items-center gap-3">
        <button className="btn btn-sm" disabled={state === "saving"}>{state === "saving" ? <span className="spinner" /> : null} Salvar e-mail</button>
        {state !== "idle" && state !== "saving" && <span role="status" className={`text-sm ${state === "ok" ? "text-glow" : "text-red-300"}`}>{msg}</span>}
      </div>
    </form>
  );
}
