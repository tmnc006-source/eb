import { Pool } from "pg";

const g = globalThis as unknown as { _pool?: Pool };
export const pool: Pool =
  g._pool ?? new Pool({ connectionString: process.env.DATABASE_URL, max: 10 });
if (process.env.NODE_ENV !== "production") g._pool = pool;

export async function query<T = any>(text: string, params: unknown[] = []): Promise<T[]> {
  const res = await pool.query(text, params);
  return res.rows as T[];
}
