export const LEVEL: Record<string, number> = { membro: 0, instrutor: 1, oficial: 2, alto_comando: 3 };
export const has = (role: string, min: keyof typeof LEVEL) => (LEVEL[role] ?? 0) >= LEVEL[min];
