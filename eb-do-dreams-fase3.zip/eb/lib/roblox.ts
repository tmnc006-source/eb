const T = () => ({ signal: AbortSignal.timeout(8000), cache: "no-store" as const });

export type RobloxUser = { id: number; name: string; displayName: string };

export class RobloxError extends Error {
  constructor(public code: "rate" | "down", msg: string) { super(msg); }
}

async function rbx(url: string, init?: RequestInit) {
  let res: Response;
  try { res = await fetch(url, { ...T(), ...init }); }
  catch { throw new RobloxError("down", "O Roblox não respondeu."); }
  if (res.status === 429) throw new RobloxError("rate", "O Roblox limitou as consultas.");
  if (!res.ok) throw new RobloxError("down", `Roblox respondeu ${res.status}.`);
  return res.json();
}

export const validUsername = (s: string) => /^[A-Za-z0-9_]{3,20}$/.test(s);

export async function findByUsername(username: string): Promise<RobloxUser | null> {
  const data = await rbx("https://users.roblox.com/v1/usernames/users", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ usernames: [username], excludeBannedUsers: true })
  });
  const u = data?.data?.[0];
  return u ? { id: u.id, name: u.name, displayName: u.displayName } : null;
}

export async function getProfile(id: number): Promise<(RobloxUser & { description: string }) | null> {
  const u = await rbx(`https://users.roblox.com/v1/users/${id}`);
  return u?.id ? { id: u.id, name: u.name, displayName: u.displayName, description: u.description ?? "" } : null;
}

export async function getAvatar(id: number): Promise<string | null> {
  try {
    const d = await rbx(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${id}&size=150x150&format=Png&isCircular=false`);
    return d?.data?.[0]?.imageUrl ?? null;
  } catch { return null; }
}

export async function getAvatars(ids: (number | string)[]): Promise<Record<string, string>> {
  const uniq = [...new Set(ids.map(String))].filter((s) => /^\d+$/.test(s)).slice(0, 100);
  if (!uniq.length) return {};
  try {
    const d = await rbx(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${uniq.join(",")}&size=150x150&format=Png`);
    const out: Record<string, string> = {};
    for (const it of d?.data ?? []) if (it.imageUrl) out[String(it.targetId)] = it.imageUrl;
    return out;
  } catch { return {}; }
}
