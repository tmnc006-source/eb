import { cookies } from "next/headers";
import { query } from "./db";
import { sha256, token } from "./crypto";

export const SESSION_COOKIE = "eb_session";
export const VF_COOKIE = "eb_vf";
const DAYS = 14;

export const cookieOpts = (maxAgeSec: number) => ({
  httpOnly: true, sameSite: "lax" as const, path: "/",
  secure: process.env.COOKIE_SECURE === "true", maxAge: maxAgeSec
});

export type SessionUser = {
  id: string; roblox_id: string; roblox_username: string; display_name: string | null;
  email: string | null; role: string; status: string; verified_at: string;
  rank_name: string | null; rank_abbr: string | null; division_name: string | null;
};

export async function createSession(userId: string) {
  const raw = token();
  await query("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES($1,$2, now() + interval '14 days')", [sha256(raw), userId]);
  cookies().set(SESSION_COOKIE, raw, cookieOpts(DAYS * 86400));
}

export async function getUser(): Promise<SessionUser | null> {
  const raw = cookies().get(SESSION_COOKIE)?.value;
  if (!raw) return null;
  const rows = await query<SessionUser>(
    `SELECT u.id, u.roblox_id::text, u.roblox_username, u.display_name, u.email, u.role, u.status, u.verified_at,
            r.name AS rank_name, r.abbreviation AS rank_abbr, d.name AS division_name
       FROM sessions s JOIN users u ON u.id = s.user_id
       LEFT JOIN ranks r ON r.id = u.rank_id LEFT JOIN divisions d ON d.id = u.division_id
      WHERE s.token_hash = $1 AND s.expires_at > now() AND u.status = 'ativo'`,
    [sha256(raw)]
  );
  return rows[0] ?? null;
}

export async function destroySession() {
  const raw = cookies().get(SESSION_COOKIE)?.value;
  if (raw) await query("DELETE FROM sessions WHERE token_hash = $1", [sha256(raw)]);
  cookies().set(SESSION_COOKIE, "", cookieOpts(0));
}
