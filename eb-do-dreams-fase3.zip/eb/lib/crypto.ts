import { createHash, randomBytes, randomInt, timingSafeEqual } from "node:crypto";

export const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");
export const token = () => randomBytes(32).toString("base64url");

export function safeEqual(a: string, b: string) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

const WORDS = ["alfa","bravo","charlie","eco","foxtrote","golfe","hotel","india","juliet","kilo","lima","mike","novembro","oscar","papa","quebec","romeu","sierra","tango","uniforme","victor","xray","zulu"];

/** Código no formato dreams-palavra-1234 (aleatório criptográfico). */
export function newCode() {
  return `dreams-${WORDS[randomInt(WORDS.length)]}-${randomInt(1000, 10000)}`;
}

/** Procura códigos no texto da bio, tolerando espaços e maiúsculas, e devolve os candidatos normalizados. */
export function extractCodes(bio: string): string[] {
  const out: string[] = [];
  const re = /dreams[\s\-_.]*([a-z]+)[\s\-_.]*(\d{4})/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(bio))) out.push(`dreams-${m[1].toLowerCase()}-${m[2]}`);
  return out;
}
