export type NavItem = { slug: string; label: string; href: string; icon: string; phase?: number; blurb?: string };

const soon = (slug: string, label: string, icon: string, phase: number, blurb: string): NavItem =>
  ({ slug, label, icon, href: `/em-breve/${slug}`, phase, blurb });

const live = (slug: string, label: string, icon: string, _phase: number, blurb: string): NavItem =>
  ({ slug, label, icon, href: `/${slug}`, blurb });

export const HOME: NavItem = { slug: "inicio", label: "Início", href: "/inicio", icon: "home" };

export const SHORTCUTS: NavItem[] = [
  soon("entregar", "Entregar", "check", 4, "Promoção de militares em lote após um treino aprovado."),
  soon("cdp", "CDP", "hourglass", 5, "Cursos, inscrições, instrutores e resultados."),
  live("registro", "Registro", "clipboard", 3, "Linha do tempo de auditoria de todas as ações."),
  soon("codigos", "Códigos", "ticket", 5, "Consulta e cópia dos códigos liberados para cada militar.")
];

export const SECTIONS: { title: string; items: NavItem[] }[] = [
  { title: "Minha carreira", items: [
    soon("codigos", "Códigos", "ticket", 5, "Consulta e cópia dos códigos liberados para cada militar."),
    soon("cdp", "Capacitação (CDP)", "hourglass", 5, "Cursos, inscrições, instrutores e resultados."),
    live("historico-de-patentes", "Histórico de Patentes", "scroll", 3, "Folha de alterações: cada promoção e rebaixamento de um militar.")
  ]},
  { title: "Quartel", items: [
    soon("agenda", "Agenda", "calendar", 4, "Treinos, operações e eventos, com aviso 10 minutos antes."),
    soon("discord", "Nosso Discord", "chat", 5, "Servidor oficial, convite e estatísticas reais."),
    live("hierarquia", "Hierarquia", "layers", 3, "Categorias e patentes configuradas pelo Alto Comando."),
    live("registro", "Registro de Ações", "clipboard", 3, "Linha do tempo de auditoria de todas as ações."),
    soon("regras", "Regras e Documentos", "book", 5, "Normas, regulamentos e formulários publicados.")
  ]},
  { title: "Comando", items: [
    soon("entregar", "Entregar Patente", "check", 4, "Promoção de militares em lote após um treino aprovado."),
    soon("divisoes", "Patentes nas Divisões", "shield", 4, "Hierarquia e pedidos dentro de cada divisão.")
  ]},
  { title: "Ajuda", items: [
    live("novidades", "Novidades", "sparkles", 3, "Comunicados e atualizações oficiais."),
    soon("bugs", "Bugs e Ideias", "bug", 5, "Envie bugs e sugestões e acompanhe pelo protocolo.")
  ]}
];

export const ALL_ITEMS: NavItem[] = [
  HOME,
  { slug: "perfil", label: "Perfil", href: "/perfil", icon: "user" },
  { slug: "patente", label: "Patente", href: "/patente", icon: "medal" },
  ...SECTIONS.flatMap((s) => s.items)
].filter((it, i, a) => a.findIndex((x) => x.href === it.href) === i);

export const TITLES: Record<string, string> = Object.fromEntries(ALL_ITEMS.map((i) => [i.href, i.label]));
