CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS rank_categories (
  id SERIAL PRIMARY KEY, name TEXT NOT NULL, color TEXT NOT NULL DEFAULT '#20F36B', position INT NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS ranks (
  id SERIAL PRIMARY KEY, category_id INT REFERENCES rank_categories(id) ON DELETE SET NULL,
  name TEXT NOT NULL, abbreviation TEXT NOT NULL, position INT NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS divisions (
  id SERIAL PRIMARY KEY, name TEXT NOT NULL, roblox_group_id BIGINT, min_rank_id INT REFERENCES ranks(id),
  emblem_url TEXT, position INT NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  roblox_id BIGINT UNIQUE NOT NULL, roblox_username TEXT NOT NULL, display_name TEXT,
  email TEXT, discord_id TEXT,
  role TEXT NOT NULL DEFAULT 'membro' CHECK (role IN ('membro','instrutor','oficial','alto_comando')),
  rank_id INT REFERENCES ranks(id), division_id INT REFERENCES divisions(id),
  status TEXT NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo','suspenso','banido')),
  verified_at TIMESTAMPTZ NOT NULL DEFAULT now(), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS verifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  roblox_id BIGINT NOT NULL, roblox_username TEXT NOT NULL,
  code_hash TEXT NOT NULL, challenge_hash TEXT NOT NULL,
  attempts INT NOT NULL DEFAULT 0, expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS verifications_challenge_idx ON verifications(challenge_hash);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS rank_history (
  id BIGSERIAL PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  from_rank_id INT REFERENCES ranks(id), to_rank_id INT REFERENCES ranks(id),
  kind TEXT NOT NULL CHECK (kind IN ('promocao','rebaixamento','reversao','ingresso','banimento')),
  reason TEXT, actor_id UUID REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_log (
  id BIGSERIAL PRIMARY KEY, actor_id UUID REFERENCES users(id), target_user_id UUID REFERENCES users(id),
  kind TEXT NOT NULL, result TEXT NOT NULL DEFAULT 'ok', description TEXT NOT NULL,
  meta JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS notifications (
  id BIGSERIAL PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT, read_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS events (
  id BIGSERIAL PRIMARY KEY, title TEXT NOT NULL, description TEXT, category TEXT,
  starts_at TIMESTAMPTZ NOT NULL, owner_id UUID REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS event_participants (
  event_id BIGINT REFERENCES events(id) ON DELETE CASCADE, user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  notified_at TIMESTAMPTZ, PRIMARY KEY (event_id, user_id)
);
CREATE TABLE IF NOT EXISTS documents (
  id BIGSERIAL PRIMARY KEY, title TEXT NOT NULL, body TEXT, kind TEXT, author_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS news (
  id BIGSERIAL PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, category TEXT, image_url TEXT,
  author_id UUID REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS reports (
  id BIGSERIAL PRIMARY KEY, protocol TEXT UNIQUE NOT NULL, kind TEXT NOT NULL CHECK (kind IN ('bug','sugestao')),
  title TEXT NOT NULL, body TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'aberto',
  user_id UUID REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS codes_catalog (
  id BIGSERIAL PRIMARY KEY, category TEXT, code TEXT NOT NULL, description TEXT, min_role TEXT NOT NULL DEFAULT 'membro'
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value JSONB NOT NULL);
